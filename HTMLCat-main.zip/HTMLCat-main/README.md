# HTMLCat
To make a simple website with HTML. I used my cat, but you can download and change the code however you want. It takes the shape of a website from the 2000's. 
The file is editible, but if it to be remixed, please credit me!
